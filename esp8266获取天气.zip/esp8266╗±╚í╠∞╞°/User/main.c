#include "stm32f4xx.h"
#include "./usart/bsp_debug_usart.h"
#include "delay.h"
#include "./led/bsp_led.h"
#include "usart1.h"

extern int TEXT,TEMP,ll;

uint16_t i=0;
extern unsigned char Xinzhi_buff[1000];
int main(void)
{
  /*��ʼ��USART ����ģʽΪ 115200 8-N-1���жϽ���*/
  Debug_USART_Config();
  LED_GPIO_Config();
  espUSART3_Config();
  delay_init();

  ESP826601S_Init();
  tq(TEXT);
  delay_ms(5000);
  Refresh_Weather();
  tq(TEXT);
  delay_ms(5000);
  Refresh_Weather();
  tq(TEXT);
  delay_ms(5000);
  Refresh_Weather();
  tq(TEXT);


  while(1)
  {

  }
}


