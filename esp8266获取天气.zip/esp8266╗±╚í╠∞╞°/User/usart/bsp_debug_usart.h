#ifndef __DEBUG_USART_H
#define	__DEBUG_USART_H

#include "stm32f4xx.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdarg.h>
#include "string.h"	
#include "delay.h"
#define REV_OK		0	
#define REV_WAIT	1	


#if defined ( __CC_ARM   )
#pragma anon_unions
#endif


#define      macUser_ESP8266_ApSsid                       "6"                //Ҫ���ӵ��ȵ������
#define      macUser_ESP8266_ApPwd                        "1234567890"           //Ҫ���ӵ��ȵ����Կ

#define      macUser_ESP8266_TcpServer_IP                 "api.seniverse.com"      //Ҫ���ӵķ������� IP
#define      macUser_ESP8266_TcpServer_Port               "80"               //Ҫ���ӵķ������Ķ˿�

#define     tianqi                                        "GET https://api.seniverse.com/v3/weather/now.json?key=SwLQ3i0Q5TNa6NSKT&location=hangzhou&language=en&unit=c"

typedef enum{
	STA,
  AP,
  STA_AP  
} ENUM_Net_ModeTypeDef;


typedef enum{
	 enumTCP,
	 enumUDP,
} ENUM_NetPro_TypeDef;
	

typedef enum{
	Multiple_ID_0 = 0,
	Multiple_ID_1 = 1,
	Multiple_ID_2 = 2,
	Multiple_ID_3 = 3,
	Multiple_ID_4 = 4,
	Single_ID_0 = 5,
} ENUM_ID_NO_TypeDef;
	

typedef enum{
	OPEN = 0,
	WEP = 1,
	WPA_PSK = 2,
	WPA2_PSK = 3,
	WPA_WPA2_PSK = 4,
} ENUM_AP_PsdMode_TypeDef;


#define RX_BUF_MAX_LEN     1024                                     //�����ջ����ֽ���

extern struct  STRUCT_USARTx_Fram                                  //��������֡�Ĵ����ṹ��
{
	char  Data_RX_BUF [ RX_BUF_MAX_LEN ];
	
  union {
    __IO u16 InfAll;
    struct {
		  __IO u16 FramLength       :15;                               // 14:0 
		  __IO u16 FramFinishFlag   :1;                                // 15 
	  } InfBit;
  }; 
	
} strEsp8266_Fram_Record;
extern struct STRUCT_USARTx_Fram strUSART_Fram_Record;



//���Ŷ���
/*******************************************************/
#define espUSART3                             USART3
#define espUSART3_CLK                         RCC_APB1Periph_USART3
#define espUSART3_BAUDRATE                    115200  //���ڲ�����

#define espUSART3_RX_GPIO_PORT                GPIOB
#define espUSART3_RX_GPIO_CLK                 RCC_AHB1Periph_GPIOB
#define espUSART3_RX_PIN                      GPIO_Pin_10
#define espUSART3_RX_AF                       GPIO_AF_USART3
#define espUSART3_RX_SOURCE                   GPIO_PinSource10

#define espUSART3_TX_GPIO_PORT                GPIOB
#define espUSART3_TX_GPIO_CLK                 RCC_AHB1Periph_GPIOB
#define espUSART3_TX_PIN                      GPIO_Pin_11
#define espUSART3_TX_AF                       GPIO_AF_USART3
#define espUSART3_TX_SOURCE                   GPIO_PinSource11

#define espUSART3_IRQHandler                  USART3_IRQHandler
#define espUSART3_IRQ                 				USART3_IRQn
/************************************************************/
#define     macESP8266_Usart( fmt, ... )           USART_printf ( USART3, fmt, ##__VA_ARGS__ ) 
#define     macPC_Usart( fmt, ... )                printf ( fmt, ##__VA_ARGS__ )

void ESP826601S_Init(void);
unsigned char *ESP8266_GetIPD_GET(unsigned short timeOut, u8 *buff);
int Get_Temp(char *y);
bool ESP8266_Cmd ( char * cmd, char * reply1, char * reply2, u32 waittime );
void ESP8266_SendData(unsigned char *data, unsigned short len);
bool ESP8266_Net_Mode_Choose ( ENUM_Net_ModeTypeDef enumMode );
bool ESP8266_AT_Test ( void );
bool ESP8266_JoinAP ( char * pSSID, char * pPassWord );
bool ESP8266_UnvarnishSend ( void );
bool ESP8266_Enable_MultipleId ( FunctionalState enumEnUnvarnishTx );
bool ESP8266_Link_Server ( ENUM_NetPro_TypeDef enumE, char * ip, char * ComNum, ENUM_ID_NO_TypeDef id);
bool ESP8266_SendString ( FunctionalState enumEnUnvarnishTx, char * pStr, u32 ulStrLength, ENUM_ID_NO_TypeDef ucId );
char * ESP8266_ReceiveString ( FunctionalState enumEnUnvarnishTx );
void cJSON_weather_Parse(void );
void ESP8266_Clear(void);
void espUSART3_Config(void);
void USART_printf ( USART_TypeDef * USARTx, char * Data, ... );
static char * itoa( int value, char *string, int radix );
void get_weather(void);
void Usart_SendString( USART_TypeDef * pUSARTx, char *str);
_Bool ESP8266_SendCmd(char *cmd, char *res);
_Bool ESP8266_WaitRecive(void);
void tq(int x);
void  Refresh_Weather(void);

#endif /* __USART1_H */
